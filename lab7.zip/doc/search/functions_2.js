var searchData=
[
  ['primo',['primo',['../tarefa4_8cpp.html#ae020263dc5e6d4e2b5055defe2af0baa',1,'tarefa4.cpp']]],
  ['print_5felementos',['print_elementos',['../tarefa2_8cpp.html#aa4a0bb1366ecac458c8d18f32623ab3c',1,'tarefa2.cpp']]]
];
