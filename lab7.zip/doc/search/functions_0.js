var searchData=
[
  ['closest2mean',['closest2mean',['../tarefa1_8cpp.html#a1a2430ad5451e2dd890d4990b2e194b4',1,'tarefa1.cpp']]]
];
